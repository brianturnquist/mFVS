
subroutine DBCHK(DEBUG,NAME,N,ICYC)
  implicit none
  logical :: DEBUG,TESTDEBUG
  integer :: N,ICYC
  character(*) :: NAME
  common /TESTDBG/ TESTDEBUG
  DEBUG = TESTDEBUG
end
subroutine PNWET(IWET)
  implicit none
  integer :: IWET,TESTWET,TESTWARN
  common /TESTCTX/ TESTWET,TESTWARN
  IWET = TESTWET
end
subroutine RCDSET(I,L)
  implicit none
  integer :: I,TESTWET,TESTWARN
  logical :: L
  common /TESTCTX/ TESTWET,TESTWARN
  if (L) TESTWARN = TESTWARN+I
end
subroutine NATCRS
  error stop 'Unexpected aspen equation in the KT/NC fixture'
end
