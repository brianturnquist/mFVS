from pathlib import Path
import sys
Path(sys.argv[1]).with_suffix('.es2').write_text('         1\n')
