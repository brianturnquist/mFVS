
subroutine DBCHK(DEBUG,NAME,N,ICYC)
  implicit none
  logical :: DEBUG,TESTDEBUG
  integer :: N,ICYC
  character(*) :: NAME
  common /TESTDBG/ TESTDEBUG
  DEBUG = TESTDEBUG
end
subroutine PNWET(IWET)
  implicit none
  integer :: IWET,TESTWET,TESTWARN,TESTCOVER
  common /TESTCTX/ TESTWET,TESTWARN,TESTCOVER
  IWET = TESTWET
end
subroutine PNFGS(ICOV)
  implicit none
  integer :: ICOV,TESTWET,TESTWARN,TESTCOVER
  common /TESTCTX/ TESTWET,TESTWARN,TESTCOVER
  ICOV = TESTCOVER
end
subroutine RCDSET(I,L)
  implicit none
  integer :: I,TESTWET,TESTWARN,TESTCOVER
  logical :: L
  common /TESTCTX/ TESTWET,TESTWARN,TESTCOVER
  if (L) TESTWARN = TESTWARN+I
end
subroutine NATCRS
  error stop 'Unexpected aspen equation in the KT/NC fixture'
end

subroutine OPFIND(N,ACT,NTODO)
  implicit none
  integer :: N,ACT(*),NTODO,TESTMODE,TESTDONE,TESTDELETE
  common /TESTADDT/ TESTMODE,TESTDONE,TESTDELETE
  NTODO = 1
  if (TESTMODE.eq.0) NTODO = 0
end
subroutine OPGET(I,N,IDT,IACTK,NP,PRMS)
  implicit none
  integer :: I,N,IDT,IACTK,NP,TESTMODE,TESTDONE,TESTDELETE
  real :: PRMS(*)
  common /TESTADDT/ TESTMODE,TESTDONE,TESTDELETE
  IDT = 2000
  IACTK = 432
  NP = 2
  PRMS(1) = 1.0
  PRMS(2) = 1.0
  if (TESTMODE.eq.3) PRMS(2) = 2.0
end
subroutine OPGETC(I,CMDLN)
  implicit none
  integer :: I
  character(*) :: CMDLN
  CMDLN = 'python3 external_model.py'
end
subroutine OPRDAT(I,KODE)
  implicit none
  integer :: I,KODE
  KODE = 0
end
subroutine OPDONE(I,IDT)
  implicit none
  integer :: I,IDT,TESTMODE,TESTDONE,TESTDELETE
  common /TESTADDT/ TESTMODE,TESTDONE,TESTDELETE
  TESTDONE = TESTDONE+1
end
subroutine OPDEL1(I)
  implicit none
  integer :: I,TESTMODE,TESTDONE,TESTDELETE
  common /TESTADDT/ TESTMODE,TESTDONE,TESTDELETE
  TESTDELETE = TESTDELETE+1
end
