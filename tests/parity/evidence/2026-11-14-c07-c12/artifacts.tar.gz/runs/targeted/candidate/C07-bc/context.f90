
subroutine DBCHK(DEBUG,NAME,N,ICYC)
  implicit none
  logical :: DEBUG,TESTDEBUG
  integer :: N,ICYC
  character(*) :: NAME
  common /TESTDBG/ TESTDEBUG
  DEBUG = TESTDEBUG
end
subroutine PNWET(IWET)
  implicit none
  integer :: IWET,TESTWET,TESTWARN,TESTCOVER
  common /TESTCTX/ TESTWET,TESTWARN,TESTCOVER
  IWET = TESTWET
end
subroutine PNFGS(ICOV)
  implicit none
  integer :: ICOV,TESTWET,TESTWARN,TESTCOVER
  common /TESTCTX/ TESTWET,TESTWARN,TESTCOVER
  ICOV = TESTCOVER
end
subroutine RCDSET(I,L)
  implicit none
  integer :: I,TESTWET,TESTWARN,TESTCOVER
  logical :: L
  common /TESTCTX/ TESTWET,TESTWARN,TESTCOVER
  if (L) TESTWARN = TESTWARN+I
end
subroutine NATCRS
  error stop 'Unexpected aspen equation in the KT/NC fixture'
end
