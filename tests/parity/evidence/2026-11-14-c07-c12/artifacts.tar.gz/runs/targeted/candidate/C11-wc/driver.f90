! Capture all fire initialization fields and species, including untouched tails.
program CHECK_FIRE_INITIALIZATION
  implicit none
  include 'PRGPRM.f90'
  include 'FMPARM.f90'
  include 'CONTRL.f90'
  include 'PLOT.f90'
  include 'FMCOM.f90'
  include 'FMFCOM.f90'
  integer :: TESTITER
  open(31,file='state.bin',access='stream',form='unformatted')
  VARACD = 'WC'
  do TESTITER = 1,2
     call FMVINIT
        write(31) 'ALLDWN',ALLDWN
        write(31) 'CANCLS',CANCLS
        write(31) 'CCCRIT',CCCRIT
        write(31) 'CORFAC',CORFAC
        write(31) 'DECAYX',DECAYX
        write(31) 'DKR',DKR
        write(31) 'DKRCLS',DKRCLS
        write(31) 'FALLX',FALLX
        write(31) 'HTR1',HTR1
        write(31) 'HTR2',HTR2
        write(31) 'HTX',HTX
        write(31) 'HTXSFT',HTXSFT
        write(31) 'IDRYB',IDRYB
        write(31) 'IDRYE',IDRYE
        write(31) 'LEAFLF',LEAFLF
        write(31) 'LIMBRK',LIMBRK
        write(31) 'LOWDBH',LOWDBH
        write(31) 'LSW',LSW
        write(31) 'LVWEST',LVWEST
        write(31) 'NZERO',NZERO
        write(31) 'OLDICT',OLDICT
        write(31) 'OLDICT2',OLDICT2
        write(31) 'OLDICTWT',OLDICTWT
        write(31) 'PBSCOR',PBSCOR
        write(31) 'PBSIZE',PBSIZE
        write(31) 'PBSMAL',PBSMAL
        write(31) 'PBSOFT',PBSOFT
        write(31) 'PBTIME',PBTIME
        write(31) 'POTEMP',POTEMP
        write(31) 'PRDUFF',PRDUFF
        write(31) 'PREWND',PREWND
        write(31) 'PSOFT',PSOFT
        write(31) 'SLCRIT',SLCRIT
        write(31) 'SNPRCL',SNPRCL
        write(31) 'TFALL',TFALL
        write(31) 'TODUFF',TODUFF
        write(31) 'V2T',V2T
     write(31) TESTITER
     V2T = -1.0
     LEAFLF = -2.0
     TFALL = -3.0
     HTX = -4.0
     FALLX = -5.0
  end do
  close(31)
  write(*,*) 'FMVINIT cases:',2
end program CHECK_FIRE_INITIALIZATION
